1. Se deschide aplicatia server
2. Introduceti numele si apasati butonul de start
3. Se deschide aplicatia client
4. Introduceti numele si apasati butonul de start
5. Apasati butonul ok in fereastra "Waiting for other player"
