﻿namespace Nu_te_supara_frate
{
    partial class fereastraJoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fereastraJoc));
            this.panelJoc = new System.Windows.Forms.Panel();
            this.pRosu4 = new System.Windows.Forms.PictureBox();
            this.pRosu3 = new System.Windows.Forms.PictureBox();
            this.pRosu2 = new System.Windows.Forms.PictureBox();
            this.pRosu1 = new System.Windows.Forms.PictureBox();
            this.pAlbastru4 = new System.Windows.Forms.PictureBox();
            this.pAlbastru3 = new System.Windows.Forms.PictureBox();
            this.pAlbastru2 = new System.Windows.Forms.PictureBox();
            this.pAlbastru1 = new System.Windows.Forms.PictureBox();
            this.labelSalut = new System.Windows.Forms.Label();
            this.labelNumeJucator = new System.Windows.Forms.Label();
            this.exitButton_Joc = new System.Windows.Forms.Button();
            this.zar1 = new System.Windows.Forms.PictureBox();
            this.labelNumeInamic = new System.Windows.Forms.Label();
            this.panelJoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zar1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelJoc
            // 
            this.panelJoc.BackgroundImage = global::Nu_te_supara_frate.Properties.Resources.nu_te_supara_frate_colorat;
            this.panelJoc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelJoc.Controls.Add(this.pRosu4);
            this.panelJoc.Controls.Add(this.pRosu3);
            this.panelJoc.Controls.Add(this.pRosu2);
            this.panelJoc.Controls.Add(this.pRosu1);
            this.panelJoc.Controls.Add(this.pAlbastru4);
            this.panelJoc.Controls.Add(this.pAlbastru3);
            this.panelJoc.Controls.Add(this.pAlbastru2);
            this.panelJoc.Controls.Add(this.pAlbastru1);
            this.panelJoc.Controls.Add(this.labelSalut);
            this.panelJoc.Location = new System.Drawing.Point(9, 10);
            this.panelJoc.Margin = new System.Windows.Forms.Padding(2);
            this.panelJoc.Name = "panelJoc";
            this.panelJoc.Size = new System.Drawing.Size(526, 585);
            this.panelJoc.TabIndex = 0;
            // 
            // pRosu4
            // 
            this.pRosu4.BackColor = System.Drawing.Color.Transparent;
            this.pRosu4.Image = ((System.Drawing.Image)(resources.GetObject("pRosu4.Image")));
            this.pRosu4.Location = new System.Drawing.Point(53, 499);
            this.pRosu4.Margin = new System.Windows.Forms.Padding(2);
            this.pRosu4.Name = "pRosu4";
            this.pRosu4.Size = new System.Drawing.Size(29, 37);
            this.pRosu4.TabIndex = 5;
            this.pRosu4.TabStop = false;
            this.pRosu4.Click += new System.EventHandler(this.pRosu4_Click);
            // 
            // pRosu3
            // 
            this.pRosu3.BackColor = System.Drawing.Color.Transparent;
            this.pRosu3.Image = ((System.Drawing.Image)(resources.GetObject("pRosu3.Image")));
            this.pRosu3.Location = new System.Drawing.Point(21, 499);
            this.pRosu3.Margin = new System.Windows.Forms.Padding(2);
            this.pRosu3.Name = "pRosu3";
            this.pRosu3.Size = new System.Drawing.Size(28, 37);
            this.pRosu3.TabIndex = 4;
            this.pRosu3.TabStop = false;
            this.pRosu3.Click += new System.EventHandler(this.pRosu3_Click);
            // 
            // pRosu2
            // 
            this.pRosu2.BackColor = System.Drawing.Color.Transparent;
            this.pRosu2.Image = ((System.Drawing.Image)(resources.GetObject("pRosu2.Image")));
            this.pRosu2.Location = new System.Drawing.Point(53, 540);
            this.pRosu2.Margin = new System.Windows.Forms.Padding(2);
            this.pRosu2.Name = "pRosu2";
            this.pRosu2.Size = new System.Drawing.Size(29, 37);
            this.pRosu2.TabIndex = 3;
            this.pRosu2.TabStop = false;
            this.pRosu2.Click += new System.EventHandler(this.pRosu2_Click);
            // 
            // pRosu1
            // 
            this.pRosu1.BackColor = System.Drawing.Color.Transparent;
            this.pRosu1.Image = ((System.Drawing.Image)(resources.GetObject("pRosu1.Image")));
            this.pRosu1.Location = new System.Drawing.Point(21, 540);
            this.pRosu1.Margin = new System.Windows.Forms.Padding(2);
            this.pRosu1.Name = "pRosu1";
            this.pRosu1.Size = new System.Drawing.Size(28, 37);
            this.pRosu1.TabIndex = 1;
            this.pRosu1.TabStop = false;
            this.pRosu1.Click += new System.EventHandler(this.pRosu1_Click);
            // 
            // pAlbastru4
            // 
            this.pAlbastru4.BackColor = System.Drawing.Color.Transparent;
            this.pAlbastru4.BackgroundImage = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pAlbastru4.Image = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru4.Location = new System.Drawing.Point(462, 59);
            this.pAlbastru4.Margin = new System.Windows.Forms.Padding(2);
            this.pAlbastru4.Name = "pAlbastru4";
            this.pAlbastru4.Size = new System.Drawing.Size(30, 35);
            this.pAlbastru4.TabIndex = 2;
            this.pAlbastru4.TabStop = false;
            this.pAlbastru4.Click += new System.EventHandler(this.pAlbastru4_Click);
            // 
            // pAlbastru3
            // 
            this.pAlbastru3.BackColor = System.Drawing.Color.Transparent;
            this.pAlbastru3.BackgroundImage = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pAlbastru3.Image = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru3.Location = new System.Drawing.Point(430, 59);
            this.pAlbastru3.Margin = new System.Windows.Forms.Padding(2);
            this.pAlbastru3.Name = "pAlbastru3";
            this.pAlbastru3.Size = new System.Drawing.Size(30, 35);
            this.pAlbastru3.TabIndex = 2;
            this.pAlbastru3.TabStop = false;
            this.pAlbastru3.Click += new System.EventHandler(this.pAlbastru3_Click);
            // 
            // pAlbastru2
            // 
            this.pAlbastru2.BackColor = System.Drawing.Color.Transparent;
            this.pAlbastru2.BackgroundImage = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pAlbastru2.Image = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru2.Location = new System.Drawing.Point(462, 20);
            this.pAlbastru2.Margin = new System.Windows.Forms.Padding(2);
            this.pAlbastru2.Name = "pAlbastru2";
            this.pAlbastru2.Size = new System.Drawing.Size(30, 35);
            this.pAlbastru2.TabIndex = 2;
            this.pAlbastru2.TabStop = false;
            this.pAlbastru2.Click += new System.EventHandler(this.pAlbastru2_Click);
            // 
            // pAlbastru1
            // 
            this.pAlbastru1.BackColor = System.Drawing.Color.Transparent;
            this.pAlbastru1.BackgroundImage = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pAlbastru1.Image = global::Nu_te_supara_frate.Properties.Resources.pionAlbastru;
            this.pAlbastru1.Location = new System.Drawing.Point(430, 20);
            this.pAlbastru1.Margin = new System.Windows.Forms.Padding(2);
            this.pAlbastru1.Name = "pAlbastru1";
            this.pAlbastru1.Size = new System.Drawing.Size(30, 35);
            this.pAlbastru1.TabIndex = 1;
            this.pAlbastru1.TabStop = false;
            this.pAlbastru1.Click += new System.EventHandler(this.pAlbastru1_Click);
            // 
            // labelSalut
            // 
            this.labelSalut.AutoSize = true;
            this.labelSalut.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSalut.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelSalut.Location = new System.Drawing.Point(52, 149);
            this.labelSalut.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelSalut.Name = "labelSalut";
            this.labelSalut.Size = new System.Drawing.Size(0, 55);
            this.labelSalut.TabIndex = 0;
            // 
            // labelNumeJucator
            // 
            this.labelNumeJucator.AutoSize = true;
            this.labelNumeJucator.BackColor = System.Drawing.Color.White;
            this.labelNumeJucator.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeJucator.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.labelNumeJucator.Location = new System.Drawing.Point(674, 93);
            this.labelNumeJucator.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNumeJucator.Name = "labelNumeJucator";
            this.labelNumeJucator.Size = new System.Drawing.Size(111, 31);
            this.labelNumeJucator.TabIndex = 1;
            this.labelNumeJucator.Text = "Jucator";
            this.labelNumeJucator.Click += new System.EventHandler(this.labelNumeJucator_Click);
            // 
            // exitButton_Joc
            // 
            this.exitButton_Joc.Location = new System.Drawing.Point(842, 561);
            this.exitButton_Joc.Margin = new System.Windows.Forms.Padding(2);
            this.exitButton_Joc.Name = "exitButton_Joc";
            this.exitButton_Joc.Size = new System.Drawing.Size(60, 19);
            this.exitButton_Joc.TabIndex = 2;
            this.exitButton_Joc.Text = "Exit";
            this.exitButton_Joc.UseVisualStyleBackColor = true;
            this.exitButton_Joc.Click += new System.EventHandler(this.exitButton_Joc_click);
            // 
            // zar1
            // 
            this.zar1.Image = global::Nu_te_supara_frate.Properties.Resources.zar1;
            this.zar1.Location = new System.Drawing.Point(658, 239);
            this.zar1.Margin = new System.Windows.Forms.Padding(2);
            this.zar1.Name = "zar1";
            this.zar1.Size = new System.Drawing.Size(126, 125);
            this.zar1.TabIndex = 3;
            this.zar1.TabStop = false;
            this.zar1.Click += new System.EventHandler(this.DaCuZarul);
            // 
            // labelNumeInamic
            // 
            this.labelNumeInamic.AutoSize = true;
            this.labelNumeInamic.BackColor = System.Drawing.Color.White;
            this.labelNumeInamic.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumeInamic.ForeColor = System.Drawing.Color.Red;
            this.labelNumeInamic.Location = new System.Drawing.Point(674, 478);
            this.labelNumeInamic.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelNumeInamic.Name = "labelNumeInamic";
            this.labelNumeInamic.Size = new System.Drawing.Size(100, 31);
            this.labelNumeInamic.TabIndex = 4;
            this.labelNumeInamic.Text = "Inamic";
            // 
            // fereastraJoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(911, 608);
            this.Controls.Add(this.labelNumeInamic);
            this.Controls.Add(this.zar1);
            this.Controls.Add(this.exitButton_Joc);
            this.Controls.Add(this.labelNumeJucator);
            this.Controls.Add(this.panelJoc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fereastraJoc";
            this.Text = "Nu te supăra frate";
            this.panelJoc.ResumeLayout(false);
            this.panelJoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pRosu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pAlbastru1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Panel panelJoc;
        private System.Windows.Forms.Label labelSalut;
        private System.Windows.Forms.Label labelNumeJucator;
        private System.Windows.Forms.Button exitButton_Joc;
        public System.Windows.Forms.PictureBox zar1;
        public System.Windows.Forms.PictureBox pAlbastru1;
        public System.Windows.Forms.PictureBox pAlbastru4;
        public System.Windows.Forms.PictureBox pAlbastru3;
        public System.Windows.Forms.PictureBox pAlbastru2;
        public System.Windows.Forms.PictureBox pRosu1;
        public System.Windows.Forms.PictureBox pRosu4;
        public System.Windows.Forms.PictureBox pRosu3;
        public System.Windows.Forms.PictureBox pRosu2;
        private System.Windows.Forms.Label labelNumeInamic;
    }
}