﻿using System.Windows.Forms;

namespace Nu_te_supara_frate
{
    public partial class FereastraCastig : Form
    {
        public FereastraCastig()
        {
            InitializeComponent();
        }
    }
}
